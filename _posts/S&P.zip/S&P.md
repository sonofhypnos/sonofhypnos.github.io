First of all: I do not provide any financial advice here. This is just a short blogpost about a forecast I made recently

So I occasionally try to make predictions on the [forecasting Site Almanis](https://app.dysruptlabs.com). Some monthly recurring questions there are of the format: By date_X, will the S&P 500 fall below Index_Y? 

To get a baseline for my predictions I made this notebook. The main reason why I publish this on my blog now, is that I want to get better at documenting and explaining it to others.

So let's get started! To make this example more concrete we will ask the question: "Will the S&P 500 go above 3900 by febuary 12th 2021?"

When you want to make predictions, it is a good idea to look for how often something has occured in the past. When it comes to an index like the S&P 500 it makes sense to make some kind of statistical model to inform your forecast, because this will outperform any any forecast you are able to make with your intuition (here is a link to some sources I highly reccomend, if you want to learn more about forecasting). 

So first a bit about markets: If you are a layperson like me, you should not expect to find any investing strategy to reliably earn money from the market through active investing. There are some caveates to this, but this is not what I am here to explain, so I'll just give you an example of what I mean: You should not believe any model you make that predicts that the S&P will go up or down tomorrow with a probability of 90% (which is enough confidence to make money by buing and selling the index fund). You should be pretty "humble" in this case because there are bunch of firms employing people smarter and more knowlegdable about finance than you that are rewarded with any exploitable strategy they can find with a heap of money. This property is what people mean when they say a market is efficient. 
This is why we will assume for this model that the S&P 500 is a random walk, which means that daily pricechanges are independent of each other (Because any dependency in the price would be "Free money" that no one bothered to pick up which is unlikely"). This is not entirely true. But is good enough for the rough model we are aiming for here.
Because changes in a random walk are independent of each other means that the only information that we have about the future index is where the index stands right now.
So when we want to answer the question whether the S&P 500 will exceed a certain index, we will look at the difference between the current index (3824,7) and the index that we want to know probability of exceedance of (3900).

For example what is the probability that the 
Of course this probability can't be taken to be exact. To be precise, I looked at how 

This was useful for betting on questions on the betting Platform Almanis. Since the site asks those questions every month, I started to do this little analysis.

So first we import some standard libraries for data analysis

If you want to look at this yourself, you can download the data here from X and here is my notebook


```python
import numpy as np #we need numpy to work with arrays in python
import pandas as pd #pandas is really handy when 
import matplotlib.pyplot as plt #this is 
import seaborn as sns #seaborn is built on top of matplotlib and has some useful plots that you can use out of the box
%matplotlib inline  

df = pd.read_csv("^GspC.csv") #This is a csv I downloaded from Yahoo finance

```

now we take a first look at our data


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1927-12-30</td>
      <td>17.660000</td>
      <td>17.660000</td>
      <td>17.660000</td>
      <td>17.660000</td>
      <td>17.660000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1928-01-03</td>
      <td>17.760000</td>
      <td>17.760000</td>
      <td>17.760000</td>
      <td>17.760000</td>
      <td>17.760000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1928-01-04</td>
      <td>17.719999</td>
      <td>17.719999</td>
      <td>17.719999</td>
      <td>17.719999</td>
      <td>17.719999</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1928-01-05</td>
      <td>17.549999</td>
      <td>17.549999</td>
      <td>17.549999</td>
      <td>17.549999</td>
      <td>17.549999</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1928-01-06</td>
      <td>17.660000</td>
      <td>17.660000</td>
      <td>17.660000</td>
      <td>17.660000</td>
      <td>17.660000</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>23266</th>
      <td>2020-08-17</td>
      <td>3380.860107</td>
      <td>3387.590088</td>
      <td>3379.219971</td>
      <td>3381.989990</td>
      <td>3381.989990</td>
      <td>3671290000</td>
    </tr>
    <tr>
      <th>23267</th>
      <td>2020-08-18</td>
      <td>3387.040039</td>
      <td>3395.060059</td>
      <td>3370.149902</td>
      <td>3389.780029</td>
      <td>3389.780029</td>
      <td>3881310000</td>
    </tr>
    <tr>
      <th>23268</th>
      <td>2020-08-19</td>
      <td>3392.510010</td>
      <td>3399.540039</td>
      <td>3369.659912</td>
      <td>3374.850098</td>
      <td>3374.850098</td>
      <td>3884480000</td>
    </tr>
    <tr>
      <th>23269</th>
      <td>2020-08-20</td>
      <td>3360.479980</td>
      <td>3390.800049</td>
      <td>3354.689941</td>
      <td>3385.510010</td>
      <td>3385.510010</td>
      <td>3642850000</td>
    </tr>
    <tr>
      <th>23270</th>
      <td>2020-08-21</td>
      <td>3386.010010</td>
      <td>3399.959961</td>
      <td>3379.310059</td>
      <td>3397.159912</td>
      <td>3397.159912</td>
      <td>3705420000</td>
    </tr>
  </tbody>
</table>
</div>



Most of those collumns we are not interested in. For our forecast we are going to only look at the closing values (As those are used in the Almanis Competition)


```python
sp = df.Close
```


```python
sp.head()
```




    0    17.660000
    1    17.760000
    2    17.719999
    3    17.549999
    4    17.660000
    Name: Close, dtype: float64




```python
sns.lineplot(x=sp.index, y=sp.values)
```




    <AxesSubplot:>




    
![png](output_11_1.png)
    


As you can see from 


```python
sns.lineplot(x=sp.index[-500:], y=sp.values[-500:])
```




    <AxesSubplot:>




    
![png](output_13_1.png)
    



```python
sp.index = pd.to_datetime(df.Date)
```

# old data gets removed


```python
sp = sp[1996:]
#sp = sp
sp_1 = sp - sp.shift()
def shift_n(ts, n):
    ts_shift = []
    for i in range(1,n+1):
        ts_shift.append((ts - ts.shift(periods=i))/ts)
    return ts_shift
```


```python
sns.lineplot(x=sp.index[-500:], y = sp.values[-500:])
```




    <AxesSubplot:xlabel='Date'>




    
![png](output_17_1.png)
    



```python
n = 15 # the number of days that the S&P has to stay within the boundary
boundary = 3400
#sp = sp[:-1] #remove close
```


```python
sp_shift = shift_n(sp, n)
sp_shift = pd.DataFrame.from_dict(dict(zip([str(x) for x in range(1,n+1)],sp_shift)))
sp_shift = sp_shift[n:]
```


```python
sp_shift["1"].rolling(window=500).mean().plot()
```




    <AxesSubplot:xlabel='Date'>




    
![png](output_20_1.png)
    



```python
sp[-5:]
```




    23266    3381.989990
    23267    3389.780029
    23268    3374.850098
    23269    3385.510010
    23270    3397.159912
    Name: Close, dtype: float64




```python
sp[-1:]
```




    23270    3397.159912
    Name: Close, dtype: float64




```python
sp_pre_forecast = float(sp[-1:]) + sp_shift * float(sp[-1:])
```


```python
# "windows" is the number of days we look back in time how values
# were excedet in the past

#windows = 1000
#sp_forecast = sp_pre_forecast[len(sp_pre_forecast)-windows:]
sp_forecast = sp_pre_forecast
```


```python
float(sp[-1:])
```




    3397.1599119999996




```python
#computing the probability of exceeding "boundry"

win = []
if float(sp[-1:]) < boundary:
    print("probability of going above boundary")
    for i in range(len(sp_forecast)):
        win.append(any(sp_forecast.iloc[i] > boundary)) 
else:
    print("probability of going below boundary")
    for i in range(len(sp_forecast)):
        win.append(any(sp_forecast.iloc[i] < boundary))

win = pd.Series(win)
print(win.mean())
win.rolling(window=30).mean().plot()
axes = plt.gca()
axes.set_ylim([0,1])
plt.show()
```

    probability of going above boundary
    0.8803857008466603
    


    
![png](output_26_1.png)
    



```python

```
